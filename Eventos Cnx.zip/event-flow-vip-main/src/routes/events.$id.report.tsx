import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import {
  ArrowLeft,
  Printer,
  AlertTriangle,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  User,
  Phone,
  Mail,
  Users,
  Paperclip,
  ClipboardList,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { StatusBadge, ItemStatusPill } from "@/components/status-badge";
import {
  allItems,
  completionRate,
  eventStatus,
  stageCompletion,
  useEvent,
} from "@/lib/events-store";
import type { ChecklistItem, EventInfo } from "@/lib/types";

export const Route = createFileRoute("/events/$id/report")({
  head: () => ({
    meta: [
      { title: "Relatório — Painel Conexão VIP" },
      { name: "description", content: "Relatório visual do evento para supervisão." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ReportPage,
  notFoundComponent: () => (
    <div className="p-10 text-center text-sm text-muted-foreground">
      Evento não encontrado.{" "}
      <Link to="/" className="underline">
        Voltar
      </Link>
    </div>
  ),
});

function formatDate(d: string) {
  if (!d) return "—";
  try {
    return new Date(`${d}T00:00:00`).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  } catch {
    return d;
  }
}

function ReportPage() {
  const { id } = Route.useParams();
  const ev = useEvent(id);
  if (!ev) throw notFound();

  const items = allItems(ev);
  const rate = completionRate(items);
  const status = eventStatus(ev);
  const done = items.filter((i) => i.status === "concluido");
  const pending = items.filter(
    (i) => i.status !== "concluido" && i.status !== "na",
  );
  const critical = pending.filter((i) => i.critical);

  const soon = pending
    .filter((i) => i.dueDate)
    .sort((a, b) => (a.dueDate ?? "").localeCompare(b.dueDate ?? ""))
    .slice(0, 6);

  return (
    <div className="bg-muted/30 py-6 print:bg-white print:py-0">
      <div className="mx-auto max-w-5xl px-4 sm:px-6">
        {/* Toolbar */}
        <div className="no-print mb-4 flex items-center justify-between gap-3">
          <Button asChild variant="ghost" size="sm" className="-ml-2">
            <Link to="/events/$id/checklist" params={{ id }}>
              <ArrowLeft className="mr-1 h-4 w-4" /> Voltar ao checklist
            </Link>
          </Button>
          <Button
            onClick={() => window.print()}
            className="bg-brand text-brand-foreground hover:bg-brand/90"
          >
            <Printer className="mr-1.5 h-4 w-4" /> Gerar relatório / Imprimir
          </Button>
        </div>

        {/* Report page */}
        <div className="rounded-2xl bg-card shadow-sm print:rounded-none print:shadow-none">
          {/* Header */}
          <div className="brand-gradient rounded-t-2xl p-6 print:rounded-none">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="text-[11px] font-bold uppercase tracking-widest text-primary/70">
                  Conexão VIP · Relatório do evento
                </div>
                <h1 className="mt-1 font-display text-3xl font-bold text-primary">
                  {ev.name}
                </h1>
                <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-primary/80">
                  <span className="inline-flex items-center gap-1">
                    <Calendar className="h-4 w-4" /> {formatDate(ev.date)}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="h-4 w-4" /> {ev.location || "—"}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <User className="h-4 w-4" /> {ev.responsible || "—"}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <StatusBadge status={status} />
                <div className="mt-2 font-display text-4xl font-bold text-primary">
                  {rate}%
                </div>
                <div className="text-[11px] uppercase tracking-wider text-primary/70">
                  Conclusão geral
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6 p-6">
            {/* Executive summary */}
            <section>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <SummaryTile
                  icon={ClipboardList}
                  label="Total de itens"
                  value={items.filter((i) => i.status !== "na").length}
                />
                <SummaryTile
                  icon={CheckCircle2}
                  label="Concluídos"
                  value={done.length}
                  tone="success"
                />
                <SummaryTile
                  icon={Clock}
                  label="Pendentes"
                  value={pending.length}
                  tone="info"
                />
                <SummaryTile
                  icon={AlertTriangle}
                  label="Itens críticos abertos"
                  value={critical.length}
                  tone={critical.length > 0 ? "critical" : "default"}
                />
              </div>
            </section>

            {/* Contatos */}
            <section>
              <SectionTitle>Informações principais</SectionTitle>
              <div className="grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-3">
                <InfoRow icon={User} label="Organizador" value={ev.organizer} />
                <InfoRow icon={User} label="Responsável" value={ev.responsible} />
                <InfoRow icon={Phone} label="Telefone" value={ev.phone} />
                <InfoRow icon={Phone} label="WhatsApp" value={ev.whatsapp} />
                <InfoRow icon={Mail} label="E-mail" value={ev.email} />
                <InfoRow icon={Users} label="Público estimado" value={ev.audience} />
                <InfoRow icon={Calendar} label="Montagem" value={ev.setupTime} />
                <InfoRow icon={Calendar} label="Evento" value={ev.eventTime} />
                <InfoRow icon={Calendar} label="Desmontagem" value={ev.teardownTime} />
              </div>
              {ev.mapLink && (
                <div className="mt-3 rounded-lg border border-border bg-muted/40 p-3 text-xs">
                  <span className="font-medium">Mapa / stand: </span>
                  {ev.mapLink}
                </div>
              )}
            </section>

            {/* Stage progress */}
            <section>
              <SectionTitle>Resumo por etapa</SectionTitle>
              <div className="space-y-2">
                {ev.stages.map((s) => {
                  const r = stageCompletion(ev, s.id);
                  const stageItems = s.groups.flatMap((g) => g.items);
                  const crit = stageItems.filter(
                    (i) => i.critical && i.status !== "concluido" && i.status !== "na",
                  ).length;
                  return (
                    <div
                      key={s.id}
                      className="rounded-lg border border-border p-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{s.title}</span>
                          {crit > 0 && (
                            <span className="inline-flex items-center gap-1 rounded border border-destructive/30 bg-destructive/10 px-1.5 py-0.5 text-[10px] font-semibold text-destructive">
                              <AlertTriangle className="h-3 w-3" /> {crit} crítico
                              {crit > 1 ? "s" : ""}
                            </span>
                          )}
                        </div>
                        <span className="text-sm font-semibold">{r}%</span>
                      </div>
                      <Progress value={r} className="mt-2 h-2" />
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Critical */}
            {critical.length > 0 && (
              <section>
                <SectionTitle tone="critical">
                  <AlertTriangle className="mr-1 inline h-4 w-4" />
                  Itens críticos em aberto
                </SectionTitle>
                <ItemList items={critical} />
              </section>
            )}

            {/* Upcoming deadlines */}
            {soon.length > 0 && (
              <section>
                <SectionTitle>Prazos próximos</SectionTitle>
                <ItemList items={soon} showDate />
              </section>
            )}

            {/* Pending list */}
            <section>
              <SectionTitle>Pendências gerais</SectionTitle>
              {pending.length === 0 ? (
                <p className="text-sm text-success">
                  Nenhuma pendência — evento pronto.
                </p>
              ) : (
                <ItemList items={pending.slice(0, 20)} />
              )}
            </section>

            {/* Per-area subchecklists */}
            <StageSection ev={ev} title="Checklist técnico" stageId="tecnico" />
            <StageSection
              ev={ev}
              title="Checklist de marketing"
              stageId="operacao"
              groupIds={["op_stand", "op_materiais"]}
            />
            <StageSection
              ev={ev}
              title="Checklist de equipe"
              stageId="operacao"
              groupIds={["op_equipe"]}
            />
            <StageSection
              ev={ev}
              title="Registros"
              stageId="operacao"
              groupIds={["op_registros"]}
            />
            <StageSection ev={ev} title="Pós-evento" stageId="pos" />

            {/* Attachments/notes */}
            <NotesSection ev={ev} />

            <footer className="border-t border-border pt-4 text-center text-[11px] text-muted-foreground">
              Relatório gerado pelo Painel de Eventos Conexão VIP ·{" "}
              {new Date().toLocaleString("pt-BR")}
            </footer>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({
  children,
  tone,
}: {
  children: React.ReactNode;
  tone?: "critical";
}) {
  return (
    <h2
      className={`mb-3 font-display text-sm font-bold uppercase tracking-wider ${
        tone === "critical" ? "text-destructive" : "text-foreground"
      }`}
    >
      {children}
    </h2>
  );
}

function SummaryTile({
  icon: Icon,
  label,
  value,
  tone = "default",
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number | string;
  tone?: "default" | "success" | "info" | "critical";
}) {
  const toneCls: Record<string, string> = {
    default: "bg-muted text-foreground",
    success: "bg-success/15 text-success",
    info: "bg-info/15 text-info",
    critical: "bg-destructive/15 text-destructive",
  };
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className={`grid h-9 w-9 place-items-center rounded-md ${toneCls[tone]}`}>
            <Icon className="h-4 w-4" />
          </div>
          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground">
              {label}
            </div>
            <div className="font-display text-xl font-bold text-foreground">{value}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-2 rounded-md border border-border bg-muted/30 p-2.5">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="truncate text-sm font-medium text-foreground">
          {value || "—"}
        </div>
      </div>
    </div>
  );
}

function ItemList({
  items,
  showDate = false,
}: {
  items: ChecklistItem[];
  showDate?: boolean;
}) {
  return (
    <ul className="divide-y divide-border rounded-lg border border-border">
      {items.map((it) => (
        <li key={it.id} className="flex flex-wrap items-center gap-3 p-3 text-sm">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{it.label}</span>
              {it.critical && (
                <span className="inline-flex items-center gap-1 rounded border border-destructive/30 bg-destructive/10 px-1.5 py-0.5 text-[10px] font-semibold text-destructive">
                  Crítico
                </span>
              )}
            </div>
            {(it.responsible || it.notes) && (
              <div className="mt-0.5 text-xs text-muted-foreground">
                {it.responsible && <span>Resp.: {it.responsible}</span>}
                {it.responsible && it.notes ? " · " : ""}
                {it.notes}
              </div>
            )}
            {it.attachment && (
              <div className="mt-0.5 inline-flex items-center gap-1 text-xs text-info">
                <Paperclip className="h-3 w-3" />
                <span className="truncate">{it.attachment}</span>
              </div>
            )}
          </div>
          {showDate && it.dueDate && (
            <span className="text-xs text-muted-foreground">
              {new Date(`${it.dueDate}T00:00:00`).toLocaleDateString("pt-BR")}
            </span>
          )}
          <ItemStatusPill status={it.status} />
        </li>
      ))}
    </ul>
  );
}

function StageSection({
  ev,
  title,
  stageId,
  groupIds,
}: {
  ev: EventInfo;
  title: string;
  stageId: string;
  groupIds?: string[];
}) {
  const stage = ev.stages.find((s) => s.id === stageId);
  if (!stage) return null;
  const groups = groupIds
    ? stage.groups.filter((g) => groupIds.includes(g.id))
    : stage.groups;
  const items = groups.flatMap((g) => g.items).filter((i) => i.status !== "na");
  if (items.length === 0) return null;
  const r = completionRate(items);
  return (
    <section>
      <div className="mb-2 flex items-center justify-between">
        <SectionTitle>{title}</SectionTitle>
        <span className="text-xs font-semibold">{r}%</span>
      </div>
      <ItemList items={items} />
    </section>
  );
}

function NotesSection({ ev }: { ev: EventInfo }) {
  const notes = allItems(ev).filter((i) => i.notes || i.attachment);
  if (notes.length === 0) return null;
  return (
    <section>
      <SectionTitle>Observações e anexos</SectionTitle>
      <div className="space-y-2">
        {notes.map((n) => (
          <div key={n.id} className="rounded-md border border-border bg-muted/30 p-3 text-xs">
            <div className="font-medium text-foreground">{n.label}</div>
            {n.notes && <div className="mt-0.5 text-muted-foreground">{n.notes}</div>}
            {n.attachment && (
              <div className="mt-0.5 inline-flex items-center gap-1 text-info">
                <Paperclip className="h-3 w-3" /> {n.attachment}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
