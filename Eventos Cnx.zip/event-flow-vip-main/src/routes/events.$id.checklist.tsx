import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import {
  ArrowLeft,
  AlertTriangle,
  FileBarChart,
  Paperclip,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { StatusBadge } from "@/components/status-badge";
import {
  allItems,
  completionRate,
  deleteEvent,
  eventStatus,
  stageCompletion,
  updateItem,
  useEvent,
} from "@/lib/events-store";
import type { ChecklistItem, ItemStatus } from "@/lib/types";

export const Route = createFileRoute("/events/$id/checklist")({
  head: () => ({
    meta: [
      { title: "Checklist do evento — Painel Conexão VIP" },
      { name: "description", content: "Checklist operacional detalhado do evento." },
    ],
  }),
  component: ChecklistPage,
  notFoundComponent: () => (
    <div className="p-10 text-center text-sm text-muted-foreground">
      Evento não encontrado.{" "}
      <Link to="/" className="underline">
        Voltar ao painel
      </Link>
      .
    </div>
  ),
});

function ChecklistPage() {
  const { id } = Route.useParams();
  const ev = useEvent(id);
  if (!ev) throw notFound();

  const items = allItems(ev);
  const rate = completionRate(items);
  const status = eventStatus(ev);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
      <div className="mb-4 flex items-center justify-between gap-3">
        <Button asChild variant="ghost" size="sm" className="-ml-2">
          <Link to="/">
            <ArrowLeft className="mr-1 h-4 w-4" /> Voltar ao painel
          </Link>
        </Button>
        <div className="flex gap-2">
          <Button asChild variant="outline" size="sm">
            <Link to="/events/$id/report" params={{ id }}>
              <FileBarChart className="mr-1.5 h-4 w-4" /> Ver relatório
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive"
            onClick={() => {
              if (confirm("Excluir este evento? Esta ação não pode ser desfeita.")) {
                deleteEvent(id);
                toast.success("Evento excluído.");
                window.history.back();
              }
            }}
          >
            <Trash2 className="mr-1 h-4 w-4" /> Excluir
          </Button>
        </div>
      </div>

      {/* Event header */}
      <Card className="overflow-hidden border-l-4 border-l-brand">
        <CardContent className="p-5">
          <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px] lg:items-center">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="truncate font-display text-2xl font-bold text-foreground">
                  {ev.name}
                </h1>
                <StatusBadge status={status} />
              </div>
              <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                <span>{ev.location || "—"}</span>
                <span>{ev.date || "—"}</span>
                <span>{ev.eventType || "—"}</span>
                <span>Responsável: {ev.responsible || "—"}</span>
              </div>
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Progresso geral</span>
                <span className="font-semibold text-foreground">{rate}%</span>
              </div>
              <Progress value={rate} className="h-2.5" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stages */}
      <div className="mt-4 space-y-3">
        {ev.stages.map((stage) => {
          const sRate = stageCompletion(ev, stage.id);
          const sCritical = stage.groups
            .flatMap((g) => g.items)
            .filter(
              (i) => i.critical && i.status !== "concluido" && i.status !== "na",
            ).length;
          return (
            <Card key={stage.id}>
              <CardHeader className="pb-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <CardTitle className="font-display text-lg">{stage.title}</CardTitle>
                    {stage.description && (
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {stage.description}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    {sCritical > 0 && (
                      <span className="inline-flex items-center gap-1 rounded-full border border-destructive/30 bg-destructive/10 px-2 py-0.5 text-[11px] font-medium text-destructive">
                        <AlertTriangle className="h-3 w-3" />
                        {sCritical} crítico{sCritical > 1 ? "s" : ""}
                      </span>
                    )}
                    <div className="w-40">
                      <div className="mb-0.5 flex items-center justify-between text-[11px] text-muted-foreground">
                        <span>Etapa</span>
                        <span className="font-semibold text-foreground">{sRate}%</span>
                      </div>
                      <Progress value={sRate} className="h-1.5" />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Accordion type="multiple" className="w-full">
                  {stage.groups.map((group) => {
                    const gRate = completionRate(group.items);
                    return (
                      <AccordionItem key={group.id} value={group.id}>
                        <AccordionTrigger className="hover:no-underline">
                          <div className="flex flex-1 items-center justify-between gap-3 pr-3">
                            <span className="text-sm font-medium">{group.title}</span>
                            <span className="text-xs text-muted-foreground">
                              {group.items.filter((i) => i.status === "concluido").length}/
                              {group.items.length} · {gRate}%
                            </span>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent>
                          <div className="space-y-2">
                            {group.items.map((it) => (
                              <ItemRow key={it.id} eventId={ev.id} item={it} />
                            ))}
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    );
                  })}
                </Accordion>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function ItemRow({ eventId, item }: { eventId: string; item: ChecklistItem }) {
  const done = item.status === "concluido";
  return (
    <div
      className={`rounded-lg border p-3 transition-colors ${
        done ? "border-success/30 bg-success/5" : "border-border bg-card"
      }`}
    >
      <div className="flex flex-wrap items-start gap-3">
        <Checkbox
          checked={done}
          onCheckedChange={(v) =>
            updateItem(eventId, item.id, {
              status: v ? "concluido" : "pendente",
            })
          }
          className="mt-1"
        />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`text-sm font-medium ${done ? "text-muted-foreground line-through" : "text-foreground"}`}
            >
              {item.label}
            </span>
            {item.critical && (
              <span className="inline-flex items-center gap-1 rounded border border-destructive/30 bg-destructive/10 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-destructive">
                <AlertTriangle className="h-3 w-3" /> Crítico
              </span>
            )}
          </div>

          <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <Label className="text-[11px] text-muted-foreground">Status</Label>
              <Select
                value={item.status}
                onValueChange={(v: ItemStatus) =>
                  updateItem(eventId, item.id, { status: v })
                }
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pendente">Pendente</SelectItem>
                  <SelectItem value="em_andamento">Em andamento</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                  <SelectItem value="na">Não se aplica</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[11px] text-muted-foreground">Responsável</Label>
              <Input
                value={item.responsible ?? ""}
                onChange={(e) =>
                  updateItem(eventId, item.id, { responsible: e.target.value })
                }
                className="h-8 text-xs"
                placeholder="Nome"
              />
            </div>
            <div>
              <Label className="text-[11px] text-muted-foreground">Prazo</Label>
              <Input
                type="date"
                value={item.dueDate ?? ""}
                onChange={(e) =>
                  updateItem(eventId, item.id, { dueDate: e.target.value })
                }
                className="h-8 text-xs"
              />
            </div>
            <div>
              <Label className="text-[11px] text-muted-foreground">
                <Paperclip className="mr-0.5 inline h-3 w-3" />
                Link / anexo
              </Label>
              <Input
                value={item.attachment ?? ""}
                onChange={(e) =>
                  updateItem(eventId, item.id, { attachment: e.target.value })
                }
                className="h-8 text-xs"
                placeholder="URL foto ou documento"
              />
            </div>
          </div>

          <div className="mt-2">
            <Textarea
              value={item.notes ?? ""}
              onChange={(e) => updateItem(eventId, item.id, { notes: e.target.value })}
              rows={2}
              placeholder="Observações…"
              className="text-xs"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
