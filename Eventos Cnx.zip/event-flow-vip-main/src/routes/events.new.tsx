import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Save } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { createEvent } from "@/lib/events-store";

export const Route = createFileRoute("/events/new")({
  head: () => ({
    meta: [
      { title: "Novo evento — Painel Conexão VIP" },
      { name: "description", content: "Cadastre um novo evento no painel Conexão VIP." },
    ],
  }),
  component: NewEventPage,
});

const fields: Array<{
  key: keyof FormData;
  label: string;
  type?: string;
  full?: boolean;
  placeholder?: string;
  textarea?: boolean;
}> = [
  { key: "name", label: "Nome do evento", full: true },
  { key: "organizer", label: "Organizador" },
  { key: "responsible", label: "Responsável" },
  { key: "phone", label: "Telefone", type: "tel" },
  { key: "whatsapp", label: "WhatsApp", type: "tel" },
  { key: "email", label: "E-mail", type: "email" },
  { key: "location", label: "Local", full: true },
  { key: "date", label: "Data", type: "date" },
  { key: "setupTime", label: "Horário de montagem", type: "time" },
  { key: "eventTime", label: "Horário do evento", type: "time" },
  { key: "teardownTime", label: "Horário de desmontagem", type: "time" },
  { key: "audience", label: "Público estimado", type: "number" },
  { key: "eventType", label: "Tipo de evento" },
  { key: "days", label: "Quantidade de dias", type: "number" },
  {
    key: "mapLink",
    label: "Mapa / observação do stand",
    full: true,
    textarea: true,
    placeholder: "Cole o link do mapa ou descreva a localização do stand…",
  },
];

type FormData = {
  name: string;
  organizer: string;
  responsible: string;
  phone: string;
  whatsapp: string;
  email: string;
  location: string;
  date: string;
  setupTime: string;
  eventTime: string;
  teardownTime: string;
  audience: string;
  eventType: string;
  days: string;
  mapLink: string;
};

const empty: FormData = {
  name: "",
  organizer: "",
  responsible: "",
  phone: "",
  whatsapp: "",
  email: "",
  location: "",
  date: "",
  setupTime: "",
  eventTime: "",
  teardownTime: "",
  audience: "",
  eventType: "",
  days: "1",
  mapLink: "",
};

function NewEventPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState<FormData>(empty);

  const update = <K extends keyof FormData>(k: K, v: FormData[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast.error("Informe o nome do evento.");
      return;
    }
    const ev = createEvent(form);
    toast.success("Evento cadastrado.");
    navigate({ to: "/events/$id/checklist", params: { id: ev.id } });
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-8">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => navigate({ to: "/" })}
        className="mb-4 -ml-2"
      >
        <ArrowLeft className="mr-1 h-4 w-4" /> Voltar
      </Button>

      <div className="mb-6">
        <h1 className="font-display text-2xl font-bold text-foreground sm:text-3xl">
          Cadastrar novo evento
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Preencha os dados principais. O checklist é criado automaticamente.
        </p>
      </div>

      <form onSubmit={onSubmit}>
        <Card>
          <CardHeader>
            <CardTitle className="font-display">Informações do evento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {fields.map((f) => (
                <div key={f.key} className={f.full ? "sm:col-span-2 lg:col-span-3" : ""}>
                  <Label htmlFor={f.key} className="mb-1.5 block text-xs font-medium">
                    {f.label}
                  </Label>
                  {f.textarea ? (
                    <Textarea
                      id={f.key}
                      value={form[f.key]}
                      onChange={(e) => update(f.key, e.target.value)}
                      placeholder={f.placeholder}
                      rows={3}
                    />
                  ) : (
                    <Input
                      id={f.key}
                      type={f.type ?? "text"}
                      value={form[f.key]}
                      onChange={(e) => update(f.key, e.target.value)}
                      placeholder={f.placeholder}
                    />
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="mt-4 flex justify-end gap-2">
          <Button type="button" variant="outline" onClick={() => setForm(empty)}>
            Limpar
          </Button>
          <Button type="submit" className="bg-brand text-brand-foreground hover:bg-brand/90">
            <Save className="mr-1.5 h-4 w-4" /> Salvar e abrir checklist
          </Button>
        </div>
      </form>
    </div>
  );
}
